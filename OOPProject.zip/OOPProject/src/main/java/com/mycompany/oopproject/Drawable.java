
package com.mycompany.oopproject;

public interface Drawable{
    public String howToDraw();
}
