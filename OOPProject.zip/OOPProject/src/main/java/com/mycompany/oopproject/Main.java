package com.mycompany.oopproject;
import javax.swing.*;
public class Main {

    public static void main(String[] args) {
        if (args.length < 3) {
            System.out.println("Error: Minimum 2 shapes are required with type and dimensions.");
            return;
        }

        int n = Integer.parseInt(args[0]);
        if (n < 2) {
            System.out.println("Error: Number of shapes must be at least 2.");
            return;
        }

        Drawable[] draws = new Drawable[n];
        int argIndex = 1;

        for (int i = 0; i < n; i++) {
            try {
                if (argIndex >= args.length) {
                    System.out.println("Error: Missing parameters.");
                    break;
                }

                String type = args[argIndex++];
                Drawable shape = null;

                if (type.equalsIgnoreCase("circle")) {
                    if (argIndex >= args.length) {
                        System.out.println("Error: Missing radius for circle.");
                        break;
                    }
                    double radius = Double.parseDouble(args[argIndex++]);
                    if (radius <= 0) {
                        System.out.println("Error: Radius must be greater than 0.");
                        break;
                    }
                    shape = new Circle("red", radius); 

                } else if (type.equalsIgnoreCase("cube")) {
                    if (argIndex >= args.length) {
                        System.out.println("Error: Missing side for cube.");
                        break;
                    }
                    double side = Double.parseDouble(args[argIndex++]);
                    if (side <= 0) {
                        System.out.println("Error: Side must be greater than 0.");
                        break;
                    }
                    shape = new Cube("red", side);

                } else {
                    System.out.println("Error: Unknown shape type. Please use 'circle' or 'cube'.");
                    break;
                }

                draws[i] = shape;

            } catch (NumberFormatException e) {
                System.out.println("Error: Invalid number format. Please check your input.");
                break;
            }
        }

        double totalArea = 0;
        for (int i = 0 ; i < draws.length ; i++){
            if(draws[i] instanceof Circle){
                Circle crcle = (Circle) draws[i];
                totalArea+=crcle.getArea();
            }
            if(draws[i] instanceof Cube){
                Cube cub = (Cube) draws[i];
                totalArea+=cub.getArea();
            }
        }
        
        System.out.println("Total area of all shapes: " + totalArea);
         Main gui = new Main();
            gui.displayAreaSum();
    }
     
    public void displayAreaSum() {
       
      String arraySizeInput = JOptionPane.showInputDialog("Enter the number of shapes (circle and cube):");
        int arraySize = Integer.parseInt(arraySizeInput);

       
        Drawable[] shapes = new Drawable[arraySize];

        
        double totalArea = 0;

        
        for (int i = 0; i < arraySize; i++) {
            String shapeChoice = JOptionPane.showInputDialog("Enter 'circle' or 'cube' for shape #" + (i + 1) + ":").toLowerCase();

            if (shapeChoice.equals("circle")) {
                
                String radiusInput = JOptionPane.showInputDialog("Enter the radius for Circle #" + (i + 1) + ":");
                double radius = Double.parseDouble(radiusInput);
                shapes[i] = new Circle(radius);  
            } else if (shapeChoice.equals("cube")) {
                
                String sideInput = JOptionPane.showInputDialog("Enter the side length for Cube #" + (i + 1) + ":");
                double side = Double.parseDouble(sideInput);
                shapes[i] = new Cube(side);  
            }

           
        }
             for(int i = 0 ; i < shapes.length ; i++){
                if(shapes[i] instanceof Circle){
                Circle crcle = (Circle) shapes[i];
                totalArea+=crcle.getArea();
                }
                if(shapes[i] instanceof Cube){
                Cube cub = (Cube) shapes[i];
                totalArea+=cub.getArea();
                }
        }

       
        JOptionPane.showMessageDialog(null, "The sum of all the areas is: " + totalArea);
    }
    }

   